import java.util.Scanner;
public class LinkedListStackTest {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);   
        
        LinkedListStack lsStack = new LinkedListStack();          
    
        System.out.println("-------------Linked List based Stack Implementation-----------------");  
           
        while(true){
            System.out.println("\nLinked List Stack Operations");
            System.out.println("1. insert data into the stack");
            System.out.println("2. remove data from the stack");
            System.out.println("3. display the top element");
            System.out.println("4. check whether stack is empty or not??");
            System.out.println("5. Present size of Stack.");
            System.out.println("6. Display the data of the stack.");
            System.out.println("7. Exit");
            int choice = scan.nextInt();
            switch (choice) 
            {
            case 1 :
                System.out.println("Enter integer element to push");
                lsStack.push( scan.nextInt() ); 
                break;                         
            case 2 :
            	lsStack.pop();
                break;  
                
            case 3 :
            	lsStack.peek();
                break;
                
            case 4 :
            	boolean flag = lsStack.isEmpty();
				if(flag){
					System.out.println("Stack is Empty.\n");
				}
				else{
					System.out.println("Stack is not Empty.\n");
				}
				break;   
                
            case 5 : 
                System.out.println("Size of the stack is  "+ lsStack.getSize()); 
                break;          
                
            case 6 : 
                lsStack.display();
                break;
                
            case 7:System.exit(0);
            
            default : 
                System.out.println("Invalid Option.... choose valid option from the menu. ");
                break;
            }           
        }  
	}

}
