import java.util.*;
 

class LinkedListStack
{
    protected ListNode top ;
    protected int size ;
 
 
    public LinkedListStack()
    {
        top = null;
        size = 0;
    }    
  
    public boolean isEmpty()
    {
        return top == null;
    }    
   
    public int getSize()
    {
        return size;
    }    
    
    public void push(int data)
    {
        ListNode nptr = new ListNode (data, null);
        if (top == null)
            top = nptr;
        else
        {
            nptr.setLink(top);
            top = nptr;
        }
        size++ ;
    }    

    public void pop(){
        if (isEmpty()){
        	
        	System.out.println("Stack is empty. POP operation cannot be performed.\n");
        }
        else{   
	        ListNode ptr = top;
	        top = ptr.getLink();
	        size-- ;
	        System.out.println(ptr.getData()+" is removed from the stack.");
        }
    }    
 
    public void peek()
    {
        if (isEmpty()){
        	System.out.println("Stack is empty. Peek operation cannot be performed.\n");
        }else{
            System.out.println(top.getData());
        }
    }    
   
    public void display()
    {
        System.out.print("\nStack:");
        if (size == 0) 
        {
            System.out.print("Empty\n");
            return ;
        }
        ListNode ptr = top;
        while (ptr != null)
        {
            System.out.println(ptr.getData());
            ptr = ptr.getLink();
        }
        System.out.println();        
    }
}

