

class ListNode
{
    protected int data;
    protected ListNode link;
 

    public ListNode()
    {
        link = null;
        data = 0;
    }    

    public ListNode(int d,ListNode n)
    {
        data = d;
        link = n;
    }    
    
    public void setLink(ListNode n)
    {
        link = n;
    }    

    public void setData(int d)
    {
        data = d;
    }    
 
    public ListNode getLink()
    {
        return link;
    }    

    public int getData()
    {
        return data;
    }
}