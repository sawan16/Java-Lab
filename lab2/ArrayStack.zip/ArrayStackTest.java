import java.util.Scanner;
public class ArrayStackTest {
	
	public static void main(String [] args){
		
		
		System.out.println("---------------Stack Implementation using Array in JAVA--------------------");
		System.out.println("Enter the Size of Stack");
		
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		
		ArrayStack stack = new ArrayStack(size);
		
		while(true){
			System.out.println("Please enter your choice:");
			System.out.println("1. Insert data into the stack");
			System.out.println("2. Remove data from the stack");
			System.out.println("3. Display the stack data");
			System.out.println("4. Check whether array is empty or not???");
			System.out.println("5. Display the top element of the stack.");
			System.out.println("6. Exit");
			
			int choice=0;
			
			choice = scanner.nextInt();
			
			
			switch(choice){
			
			case 1:
				System.out.println("Enter data to insert in the stack");
				int data = scanner.nextInt();
				stack.push(data);
				break;
				
			case 2:
				stack.pop();
				break;
			
			case 3:
				stack.display();
				break;
			
			case 4:
				boolean flag = stack.isEmpty();
				if(flag){
					System.out.println("Stack is Empty.\n");
				}
				else{
					System.out.println("Stack is not Empty.\n");
				}
				break;
				
			case 5:
				stack.peek();
				break;
				
			case 6:
				System.exit(0);
				
			default:
				System.out.println("Invalid option. Please select valid options from the menu.\n");
			
			}
		}
	}
}
