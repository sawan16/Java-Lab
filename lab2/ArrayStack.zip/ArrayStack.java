
public class ArrayStack {
	
	private int size;
	private int top;
	private int [] array;
	
	public ArrayStack(int size){
		
		this.size = size;
		this.array = new int[size];
		this.top = -1;
		
	}

	public boolean isEmpty(){
		
		return this.top == -1;
	}
	
	public void push(int data){
		
		if(top==size-1){
			System.out.println("Stack is full. data cannot be inserted.\n");
		}
		else{
			array[++top]= data;
		}
	}
	
	public void pop(){
		
		if(isEmpty()){
			
			System.out.println("Stack is empty. POP operation cannot be performed.\n");
		}
		else{
			
			System.out.println(array[top--]+ " is removed from the stack.\n");
		}
	}
	
	public void peek(){
		
		if(isEmpty()){
			System.out.println("Stack is empty. Peek operation cannot be performed.\n");

		}
		else{
			System.out.println(array[top]);
		}
	}
	
	public void display(){
		int itr = top;
		while(itr!=-1){
			System.out.println(array[itr]);
			itr--;
		}
	}
}
