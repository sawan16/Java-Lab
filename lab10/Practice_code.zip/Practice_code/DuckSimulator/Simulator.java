import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border; 
public class Simulator
{ 
    private JFrame frame; 
  
    public static void main(String[] args) 
    { 
        Simulator sim = new Simulator(); 
        
     
        sim.frame =new JFrame(); 
          
        
        
        JButton button1 = new JButton("Mallard Duck"); 
        JButton button2 = new JButton("Decoy Duck"); 
        JButton button3 = new JButton("RedHead Duck"); 
        JButton button4 = new JButton("Rubber Duck"); 
        
        button1.setBounds(50, 50, 120, 50); 
        button2.setBounds(180, 50, 120, 50);
        button3.setBounds(310, 50, 120, 50);
        button4.setBounds(440, 50, 120, 50);
        
        JLabel label = new JLabel();
        label.setText("");
        label.setBounds(100, 200, 300, 100);
        
        
        Border border = BorderFactory.createLineBorder(Color.cyan, 1);
    
        label.setBorder(border);

       
        sim.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  
        
        
        sim.frame.add(button1); 
        sim.frame.add(button2);
        sim.frame.add(button3);
        sim.frame.add(button4);
        sim.frame.add(label);
        
        JLabel imgLabel = new JLabel();
        ImageIcon icon = new ImageIcon ();
        imgLabel.setIcon(icon);
        
        button1.addActionListener(new ActionListener(){  
            public void actionPerformed(ActionEvent e) {  
                    label.setText("<html>"+(new MallardDuck().display())+" <html>");
                    ImageIcon icon = new ImageIcon ("src/md.jpg");
                    imgLabel.setIcon(icon);
            }  
            });
        
        button2.addActionListener(new ActionListener(){  
            public void actionPerformed(ActionEvent e){  
                    label.setText("<html>"+(new DecoyDuck().display())+" <html>");
                    ImageIcon icon = new ImageIcon ("src/dd.jpg");
                    imgLabel.setIcon(icon);
            }  
            });
        
        button3.addActionListener(new ActionListener(){  
            public void actionPerformed(ActionEvent e){  
                    label.setText("<html>"+(new RedHeadDuck().display())+" <html>");
                    ImageIcon icon = new ImageIcon ("src/rhd.jpg");
                    imgLabel.setIcon(icon);
            }  
            });
        
        button4.addActionListener(new ActionListener(){  
            public void actionPerformed(ActionEvent e){  
                    label.setText("<html>"+(new RubberDuck().display())+" <html>");
                    ImageIcon icon = new ImageIcon ("src/rd.jpg");
                    imgLabel.setIcon(icon);
            }  
            });
        
        
        
        JPanel panel1 = new JPanel();
        panel1.add(button1);
        panel1.add(button2);
        panel1.add(button3);
        panel1.add(button4);
        panel1.setBackground(Color.darkGray);
        Border border2 = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
        panel1.setBorder(border2);
        sim.frame.add(panel1,BorderLayout.SOUTH);
        
        
        JPanel panel2 = new JPanel();
        Border border3 = BorderFactory.createLineBorder(Color.black, 3);
        panel2.setBorder(border3);
        panel2.add(label);
        panel2.add(imgLabel);
        sim.frame.add(panel2, BorderLayout.NORTH);
        
        sim.frame.setSize(600, 400); 
        
        sim.frame.setTitle("Duck Simulator");
        
        sim.frame.setVisible(true); 
    } 
} 