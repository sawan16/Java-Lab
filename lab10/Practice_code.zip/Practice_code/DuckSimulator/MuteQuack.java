
public class MuteQuack implements QuackBehavior {

	@Override
	public String quack() {
		return " I cann't Quack..";

	}

}
