
public class Squeak implements QuackBehavior {

	@Override
	public String quack() {
		return " I can Squeak..";

	}

}
