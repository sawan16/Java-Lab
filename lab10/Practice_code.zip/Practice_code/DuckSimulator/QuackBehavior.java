
public interface QuackBehavior {
	
	public String quack();

}
