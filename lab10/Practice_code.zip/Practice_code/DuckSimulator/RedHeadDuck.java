
public class RedHeadDuck extends Duck {

	public RedHeadDuck() {
		super(new FlyNoWay(), new Quack());
		
	}



	@Override
	public String  display() {
		return "I am Red Head Duck.. <br /> "+ super.performFlyBehavior() + super.performQuackBehavior();
	}

}
