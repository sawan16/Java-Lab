
public abstract class Duck {
	
	private FlyBehavior flyBehavior;
	private QuackBehavior quackBehavior;
	
	public Duck(FlyBehavior flyBehavior, QuackBehavior quackBehavior) {
		this.flyBehavior = flyBehavior;
		this.quackBehavior = quackBehavior;
	}
	
	public void swin()
	{
		System.out.println("swin..!!!");

	}
	public abstract String display();
	
	public String performFlyBehavior()
	{
		//TODO: function
		return this.flyBehavior.fly();
	}
	
	public String performQuackBehavior()
	{
		//TODO: function
		return this.quackBehavior.quack();
	}


}
