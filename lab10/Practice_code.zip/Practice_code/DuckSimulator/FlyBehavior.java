
public interface FlyBehavior {
	
	public String fly();

}
