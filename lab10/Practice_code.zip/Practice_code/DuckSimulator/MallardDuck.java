
public class MallardDuck extends Duck {

	public MallardDuck() {
		
		super(new FlyWithWings(), new Quack() );
	
	}


	@Override
	public String display() {
		
		String text ="";
		text="I am Mallard Duck.. <br /> ";
		text+=super.performFlyBehavior();
		text+=super.performQuackBehavior();
		
		return text;
		
	}

}
