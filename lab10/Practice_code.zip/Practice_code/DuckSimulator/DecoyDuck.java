
public class DecoyDuck extends Duck {

	public DecoyDuck() {
		super(new FlyNoWay(),new MuteQuack());
		
	}



	@Override
	public String display() {
		return "I am Decoy Duck.. <br /> "+ super.performFlyBehavior() + super.performQuackBehavior();
	}

}
