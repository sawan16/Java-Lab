
public class RubberDuck extends Duck {

	public RubberDuck() {
		super(new FlyNoWay(), new Squeak());
	}



	@Override
	public String display() {
		return "I am Rubber Duck.. <br /> "+ super.performFlyBehavior() + super.performQuackBehavior();
		
	}

}
