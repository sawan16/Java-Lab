import static org.junit.Assert.*;

import org.junit.Test;

public class FactorialJunitTest {

	@Test
	public void testFactorial1() {
		
		Factorial f = new Factorial();
		assertEquals(new Long(24),f.findFactorial("4"));
	}
	
	@Test(expected = NumberFormatException.class)
	public void testFactorial2() {
		
		Factorial f = new Factorial();
		f.findFactorial("t");
	}

}
