import java.io.*;
import java.util.Scanner;
public class Factorial{
	
	private Integer number;
	private Long result;
	
	public Long getResult() {
		return result;
	}


	public void setResult(Long result) {
		this.result = result;
	}


	public Integer getNumber() {
		return number;
	}


	public void setNumber(Integer number) {
		this.number = number;
	}

	public Long findFactorial(String number) throws NumberFormatException{
			
			this.number = Integer.parseInt(number);
			for(int i = this.number ;i>0;i--)
				result*=i;
		
		return result;
		
	}

	public static void main(String [] args)throws Exception{
		
		try{
			Scanner sc = new Scanner(System.in);
			String number = sc.next();
			Factorial f = new Factorial();
			System.out.println(f.findFactorial(number));
		}catch(NumberFormatException e){
			System.out.println("Please enter a vaild Integer");
		}
	}
}
