
public class MacOS extends OperatingSystem {

	@Override
	public void performFileOperations() {
		System.out.println("MacOS File operations.................");

	}

	@Override
	public void performMemoryOperations() {
		System.out.println("MacOS Memory operations.................");

	}

	@Override
	public void performProcessManagement() {
		System.out.println("MacOS Process mangement operations.................");

	}

}
