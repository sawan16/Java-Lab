
public interface FileOperations {

	void performFileOperations();
}
