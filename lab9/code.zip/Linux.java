
public class Linux extends OperatingSystem {

	@Override
	public void performFileOperations() {
		System.out.println("Linux File operations.................");

	}

	@Override
	public void performMemoryOperations() {
		System.out.println("Linux Memory operations.................");

	}

	@Override
	public void performProcessManagement() {
		System.out.println("Linux Process mangement operations.................");

	}

}
