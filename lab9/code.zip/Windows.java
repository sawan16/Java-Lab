
public class Windows extends OperatingSystem {

	@Override
	public void performFileOperations() {
		System.out.println("Windows File operations.................");

	}

	@Override
	public void performMemoryOperations() {
		System.out.println("Windows Memory operations.................");

	}

	@Override
	public void performProcessManagement() {
		System.out.println("Windows Process mangement operations.................");

	}

}
