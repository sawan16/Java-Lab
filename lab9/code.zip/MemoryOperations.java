
public interface MemoryOperations {
	
	void performMemoryOperations();

}
