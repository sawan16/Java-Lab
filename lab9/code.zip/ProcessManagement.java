
public interface ProcessManagement {
	
	void performProcessManagement();

}
