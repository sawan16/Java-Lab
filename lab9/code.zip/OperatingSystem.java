
public abstract class OperatingSystem implements FileOperations, MemoryOperations, ProcessManagement{
	
	private Long memoryRequired;
	private Byte bit;
	
	public Long getMemoryRequired() {
		return memoryRequired;
	}
	public void setMemoryRequired(Long memoryRequired) {
		this.memoryRequired = memoryRequired;
	}
	public Byte getBit() {
		return bit;
	}
	public void setBit(Byte bit) {
		this.bit = bit;
	}
	
	public String toString(){
		
		return this.getClass().getName();
	}
	
	public void performBootUp(){
		
		System.out.println(" OS bootup operation.................");
	}
	
}
