import java.util.*;
public class Computer {
	
	private List<OperatingSystem> operatingSystems;
	
	
	public List<OperatingSystem> getOperatingSystems() {
		return operatingSystems;
	}


	public void setOperatingSystems(List<OperatingSystem> operatingSystems) {
		this.operatingSystems = operatingSystems;
	}


	public static void main(String [] args){
		
		Computer computer = new Computer();
		
		OperatingSystem os = new Windows();
		
		ArrayList<OperatingSystem> list = new ArrayList<OperatingSystem>();
		list.add(os);
		computer.setOperatingSystems(list);
		System.out.println(computer.getOperatingSystems());
		
		computer.operatingSystems.get(0).performFileOperations();
		
	}

}
