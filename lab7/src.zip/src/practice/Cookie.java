package practice;

public class Cookie extends Dessert {

	private Double costPerDozen;
	private Integer count;
	
	
	public Double getCostPerDozen() {
		return costPerDozen;
	}


	public void setCostPerDozen(Double costPerDozen) {
		this.costPerDozen = costPerDozen;
	}


	public Integer getCount() {
		return count;
	}


	public void setCount(Integer count) {
		this.count = count;
	}


	public Cookie(String name, Double costPerDozen, Integer count) {
		super(name);
		this.costPerDozen = costPerDozen;
		this.count = count;
		System.out.println("Cookie class constructor......");
	}


	public Double calculateCost() {
		
		return count*(costPerDozen/12);
	}

}
