package practice;

import java.util.*;
public class DessertCollection {

	private List<Dessert> desserts;
	private Double totalCost = 0.0;
	
	
	public List<Dessert> getDesserts() {
		return desserts;
	}


	public void setDesserts(List<Dessert> desserts) {
		this.desserts = desserts;
	}


	public Double getTotalCost() {
		for(Dessert d: desserts){
			totalCost += d.calculateCost();
		}
		
		return totalCost;
	}


	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}


	public static void main(String[] args) {
		
		DessertCollection dc = new DessertCollection();
		dc.desserts = new ArrayList<Dessert>();
		dc.desserts.add(new Candy("candy",0.5,34.0));
		dc.desserts.add(new Cookie("cookie",84.0,5));
		dc.desserts.add(new IceCream("IceCream",78.0));
		System.out.println(dc.getTotalCost());
		

	}

}
