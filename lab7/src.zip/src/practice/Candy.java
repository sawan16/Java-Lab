package practice;

public class Candy extends Dessert {

	private Double weight;
	private Double costPerPound;
	
	
	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getCostPerPound() {
		return costPerPound;
	}

	public void setCostPerPound(Double costPerPound) {
		this.costPerPound = costPerPound;
	}

	public Candy(String name, Double weight, Double costPerPound) {
		super(name);
		this.weight = weight;
		this.costPerPound = costPerPound;
		System.out.println("Candy class constructor......");
	}

	public Double calculateCost() {
		return weight*costPerPound;
	}

}
