package practice;

public abstract class Dessert {
	private String name;

	public Dessert(String name) {
		super();
		this.name = name;
		System.out.println("Dessert class constructor......");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public abstract Double calculateCost();
	

}
