package practice;

public abstract class Cake extends Dessert {

	
	private Double weight;
	private Double costPerPound;
	
	
	
	public Double getWeight() {
		return weight;
	}



	public void setWeight(Double weight) {
		this.weight = weight;
	}



	public Double getCostPerPound() {
		return costPerPound;
	}



	public void setCostPerPound(Double costPerPound) {
		this.costPerPound = costPerPound;
	}



	public Cake(String name, Double weight, Double costPerPound) {
		
		super(name);
		this.weight = weight;
		this.costPerPound = costPerPound;
		System.out.println("Cake class constructor......");
	}
	
	

}
