package practice;

public class NormalCake extends Cake {
	
	

	public NormalCake(String name, Double weight, Double costPerPound) {
		super(name, weight, costPerPound);
		System.out.println("Normal Cake class constructor......");
	}

	@Override
	public Double calculateCost() {
		
		return super.getWeight()*super.getCostPerPound();
	}

}
