package practice;

public class ChocolateCake extends Cake {
	
	private Double chocolateWeight;
	private Double chocolateCostPerPound;
	
	
	

	public ChocolateCake(String name, Double weight, Double costPerPound, Double chocolateWeight,
			Double chocolateCostPerPound) {
		super(name, weight, costPerPound);
		this.chocolateWeight = chocolateWeight;
		this.chocolateCostPerPound = chocolateCostPerPound;
		System.out.println("Chocolate Cake class constructor......");
	}




	@Override
	public Double calculateCost() {
		return super.getWeight()*super.getCostPerPound()+this.chocolateCostPerPound*this.chocolateWeight;
	}

}
