package practice;

public class IceCream extends Dessert {
	
	private Double cost;
	
	

	public IceCream(String name, Double cost) {
		super(name);
		this.cost = cost;
		System.out.println("Ice Cream class constructor......");
	}

	


	public Double getCost() {
		return cost;
	}




	public void setCost(Double cost) {
		this.cost = cost;
	}




	@Override
	public Double calculateCost() {
		return cost;
	}

}
