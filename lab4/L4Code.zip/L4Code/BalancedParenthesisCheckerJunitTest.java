

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BalancedParenthesisCheckerJunitTest {

	
	@Test
	public void testAreParenthesisBalanced() {
		
		BalancedParenthesisChecker checker = new BalancedParenthesisChecker(new Expression("a+(89*7)+{56+(6+45)*43}+[4+{7*(4-9)}]"));
		assertTrue(checker.areParenthesisBalanced());		
		
	}
	
	@Test
	public void testAreParenthesisBalanced2() {
		
		BalancedParenthesisChecker checker = new BalancedParenthesisChecker(new Expression("{45}+(789"));
		assertFalse(checker.areParenthesisBalanced());		
		
	}
	
	@Test
	public void testIsMathingPair() {
		
		assertTrue(BalancedParenthesisChecker.isMatchingPair('{','}'));		
		
	}
	
	@Test
	public void testIsMathingPair2() {
		
		assertFalse(BalancedParenthesisChecker.isMatchingPair('{','('));		
		
	}

}
