

import java.util.ArrayList;
public class ArrayStack {
	
	private Integer size;
	private Integer top;
	private Character [] array;
	
	public ArrayStack(Integer size){
		
		this.size = size;
		this.array = new Character[size];
		this.top = -1;
		
	}

	public Boolean isEmpty(){
		
		return this.top == -1;
	}
	
	public Character push(Character data){
		
		if(top==size-1){
			System.out.println("Stack is full. data cannot be inserted.\n");
		}
		else{
			array[++top]= data;
		}
		return peek();
	}
	
	public Character pop(){
		
		if(isEmpty()){
			return null;
		}
		else{
			
			return array[top--];
		}
	}
	
	public Character peek(){
		
		if(isEmpty()){
			return null;
		}
		else{
			
			return array[top];
		}
	}
	
	public ArrayList display(){
		ArrayList list = new ArrayList();
		Integer itr = top;
		while(itr!=-1){
			
			list.add(array[itr]);
			itr--;
		}
		return list;
	}
}

