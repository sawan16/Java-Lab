
import static org.junit.Assert.*;

import org.junit.Test;

public class InfixToPostfixJunitTest {
	
	@Test
	public void testPerformInfixToPostfix() {

		String exp = "a+b";
		Expression expression = new Expression(exp);
		InfixToPostfix iTop = new InfixToPostfix(expression);
		assertEquals("ab+",iTop.performInfixToPostfix(exp));

	}
	
	@Test
	public void testPerformInfixToPostfix2() {

		String exp = "a+b*(c^d-e)^(f+g*h)-i";
		Expression expression = new Expression(exp);
		InfixToPostfix iTop = new InfixToPostfix(expression);
		assertEquals("abcd^e-fgh*+^*+i-",iTop.performInfixToPostfix(exp));

	}
	
	@Test
	public void testPerformInfixToPostfix3() {

		String exp = "A+B*C+D";
		Expression expression = new Expression(exp);
		InfixToPostfix iTop = new InfixToPostfix(expression);
		assertEquals("ABC*+D+",iTop.performInfixToPostfix(exp));

	}
	
	@Test
	public void testPerformInfixToPostfix4() {

		String exp = "A+B+C+D";
		Expression expression = new Expression(exp);
		InfixToPostfix iTop = new InfixToPostfix(expression);
		assertEquals("AB+C+D+",iTop.performInfixToPostfix(exp));

	}

}

