

public class BalancedParenthesisChecker
{
	private Expression expression ;
	
	public Expression getExpression() {
		return expression;
	}

	public void setExpression(Expression expression) {
		this.expression = expression;
	}

	public BalancedParenthesisChecker(Expression e){
		this.expression = e;
	}
 
 public static boolean isMatchingPair(char character1, char character2)
 {
    if (character1 == '(' && character2 == ')')
      return true;
    else if (character1 == '{' && character2 == '}')
      return true;
    else if (character1 == '[' && character2 == ']')
      return true;
    else
      return false;
 }
  

 public boolean areParenthesisBalanced()
 {
  
    ArrayStack stack =new ArrayStack(100);
   
    String expression = this.expression.getExpression();
    for(int i=0;i<expression.length();i++)
    {
        char tmp = expression.charAt(i);
       
       if (tmp == '{' || tmp == '(' || tmp == '[')
         stack.push(tmp);
   
       
       if (tmp == '}' || tmp == ')' || tmp == ']')
       {
               
           
          if (stack.isEmpty())
            {
                return false;
            } 
   
         
          else if ( !isMatchingPair(stack.pop(), tmp) )
            {
                return false;
            }
       }
        
    }
      
    if (stack.isEmpty())
      return true; 
    else
      {   
          return false;
      } 
 } 
}